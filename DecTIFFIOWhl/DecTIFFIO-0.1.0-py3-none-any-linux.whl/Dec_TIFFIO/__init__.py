import os
import sys

if sys.version_info[:2] >= (3, 7):
    #os.add_dll_directory(os.path.abspath(os.path.dirname(__file__)) + '/dll')
    sys.path.append(os.path.abspath(os.path.dirname(__file__)) + '/dll/')
    sys.path.append(os.path.abspath(os.path.dirname(__file__)) + '/')
else:
    os.environ['path'] = os.path.abspath(os.path.dirname(__file__)) + '/dll;' + os.environ['path']

print(sys.path)

from .SpeedTiff import *
from .DecWriteTif import *
from .DecReadTif import *
